# HI — AI assistant starter

A responsive web app/PWA starter with email/password accounts, SQLite persistence, per-user chat history, and optional OpenAI Responses API integration.

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract the project folder.
2. Open a terminal in the `hi-app` folder.
3. Install dependencies: `npm install`
4. Copy `.env.example` to `.env` (Windows PowerShell: `Copy-Item .env.example .env`; macOS/Linux: `cp .env.example .env`).
5. Start: `npm start`
6. Open `http://localhost:3000`.

Registration works without an AI API key. Without `OPENAI_API_KEY`, HI stores the messages and shows a setup explanation instead of calling a model.

## Enable real AI replies
1. Create an API key with your chosen AI provider/account.
2. Put it in `.env` as `OPENAI_API_KEY=...` (never paste it into browser JavaScript or commit `.env`).
3. Set `OPENAI_MODEL` to a model your account can use.
4. Restart `npm start`.

AI API usage may cost money. The server uses the OpenAI Responses API endpoint. Never publish the key or expose it to client-side code.

## Features
- Responsive dark UI, suggestion prompts, chat list, delete chat
- Register, login, logout
- Password hashing with bcryptjs
- SQLite users/chats/messages, user-scoped chat access
- Rate limits on authentication and AI message routes
- PWA manifest, SVG icon, basic offline shell cache
- API health endpoint: `GET /api/health`

## Important production hardening
This starter is for local development and learning, not a fully hardened public launch. Before public deployment:
- Replace express-session’s default MemoryStore with a persistent session store (SQLite/Redis). Session ID rotation is already performed on registration and login.
- Set a strong random `SESSION_SECRET`, `NODE_ENV=production`, HTTPS, and secure cookie settings.
- Add email verification, password reset, CSRF protections appropriate to your deployment, privacy/retention controls, backups, monitoring, and stronger abuse controls.
- Use persistent disk for SQLite; do not deploy to an ephemeral filesystem.
- Review provider terms, usage costs, and applicable privacy rules.

## Database
By default the database is created at `./data/hi.sqlite`. It is generated automatically on first start. Back it up securely; it contains user emails, password hashes, and chat content.
