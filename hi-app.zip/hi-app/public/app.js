(() => {
  const $ = selector => document.querySelector(selector);
  const welcome = $('#welcome'), conversation = $('#conversation'), composer = $('#composer'), input = $('#messageInput');
  const authModal = $('#authModal'), authForm = $('#authForm'), authError = $('#authError');
  let currentUser = null, currentChatId = null, chats = [], authMode = 'login', sending = false, toastTimer;

  async function api(url, options = {}) {
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) } });
    let data = {};
    try { data = await response.json(); } catch (_) { data = {}; }
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  }
  function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3200); }
  function setBusy(value) { sending = value; $('#sendButton').disabled = value; $('#sendButton').innerHTML = value ? '…' : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/></svg>'; }
  function showWelcome() { welcome.classList.remove('hidden'); conversation.classList.add('hidden'); }
  function showConversation() { welcome.classList.add('hidden'); conversation.classList.remove('hidden'); }
  function addMessage(role, content, extraClass = '') {
    showConversation();
    const row = document.createElement('article'); row.className = `message ${role} ${extraClass}`.trim();
    const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = role === 'assistant' ? 'h' : (currentUser?.email?.[0] || 'Я').toUpperCase();
    const body = document.createElement('div'); body.className = 'message-content'; body.textContent = content;
    row.append(avatar, body); conversation.append(row); row.scrollIntoView({ behavior: 'smooth', block: 'end' }); return row;
  }
  function renderAccount() {
    $('#accountLabel').textContent = currentUser ? currentUser.email.split('@')[0] : 'Войти';
    $('#avatar').textContent = currentUser ? currentUser.email[0].toUpperCase() : '?';
    $('#connectionText').textContent = currentUser ? 'История сохраняется в аккаунте' : 'Войди, чтобы сохранять историю';
    $('#newChat').disabled = !currentUser;
    $('#newChat').style.opacity = currentUser ? '1' : '.7';
  }
  function renderChats() {
    const list = $('#chatList'); list.replaceChildren();
    if (!currentUser) { const p = document.createElement('p'); p.className = 'muted small'; p.textContent = 'Войди, чтобы сохранять историю.'; list.append(p); return; }
    if (!chats.length) { const p = document.createElement('p'); p.className = 'muted small'; p.textContent = 'Твои новые чаты появятся здесь.'; list.append(p); return; }
    for (const chat of chats) {
      const row = document.createElement('div'); row.className = `chat-item${chat.id === currentChatId ? ' active' : ''}`;
      const icon = document.createElement('span'); icon.textContent = '◌'; icon.style.color = '#a99bd2';
      const title = document.createElement('button'); title.className = 'chat-item-title'; title.textContent = chat.title; title.title = chat.title; title.addEventListener('click', () => openChat(chat.id));
      const remove = document.createElement('button'); remove.className = 'delete-chat'; remove.textContent = '×'; remove.title = 'Удалить чат'; remove.setAttribute('aria-label', `Удалить ${chat.title}`); remove.addEventListener('click', async e => { e.stopPropagation(); if (!confirm(`Удалить чат «${chat.title}»?`)) return; try { await api(`/api/chats/${encodeURIComponent(chat.id)}`, { method: 'DELETE' }); chats = chats.filter(c => c.id !== chat.id); if (currentChatId === chat.id) { currentChatId = null; conversation.replaceChildren(); showWelcome(); } renderChats(); } catch (err) { toast(err.message); } });
      row.append(icon, title, remove); list.append(row);
    }
  }
  async function loadChats() { if (!currentUser) return; const data = await api('/api/chats'); chats = data.chats; renderChats(); }
  async function startChat() {
    if (!currentUser) { openAuth('login'); toast('Войди или создай аккаунт, чтобы сохранять чаты.'); return null; }
    const data = await api('/api/chats', { method: 'POST', body: JSON.stringify({}) });
    currentChatId = data.chat.id; chats.unshift(data.chat); conversation.replaceChildren(); showWelcome(); renderChats(); input.focus(); return currentChatId;
  }
  async function openChat(id) {
    if (!currentUser) return;
    try { const data = await api(`/api/chats/${encodeURIComponent(id)}/messages`); currentChatId = id; conversation.replaceChildren(); for (const message of data.messages) addMessage(message.role, message.content); if (!data.messages.length) showWelcome(); renderChats(); closeSidebar(); }
    catch (err) { toast(err.message); }
  }
  function openAuth(mode = 'login') { setAuthMode(mode); authError.textContent = ''; authModal.classList.remove('hidden'); setTimeout(() => $('#email').focus(), 40); }
  function closeAuth() { authModal.classList.add('hidden'); }
  function setAuthMode(mode) {
    authMode = mode;
    document.querySelectorAll('.auth-tab').forEach(tab => tab.classList.toggle('active', tab.dataset.mode === mode));
    $('#authTitle').textContent = mode === 'login' ? 'С возвращением' : 'Создай свой аккаунт';
    $('#authDescription').textContent = mode === 'login' ? 'Войди, чтобы продолжить свои диалоги.' : 'Твоя история будет храниться в личном пространстве.';
    $('#authSubmit').innerHTML = mode === 'login' ? 'Войти в HI <span>→</span>' : 'Создать аккаунт <span>→</span>';
    $('#passwordNote').classList.toggle('hidden', mode === 'login');
    $('#password').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  }
  async function refreshMe() {
    try { const data = await api('/api/me'); currentUser = data.user; renderAccount(); await loadChats(); }
    catch (err) { $('#connectionText').textContent = 'Не удалось подключиться к серверу'; toast(err.message); }
  }
  async function sendMessage(text) {
    const message = (text ?? input.value).trim(); if (!message || sending) return;
    if (!currentUser) { openAuth('login'); toast('Сначала войди или создай аккаунт.'); return; }
    if (!currentChatId) { try { await startChat(); } catch (err) { toast(err.message); return; } }
    input.value = ''; input.style.height = 'auto'; addMessage('user', message); const pending = addMessage('assistant', 'HI думает…', 'typing'); setBusy(true);
    try {
      const data = await api(`/api/chats/${encodeURIComponent(currentChatId)}/messages`, { method: 'POST', body: JSON.stringify({ message }) });
      pending.querySelector('.message-content').textContent = data.assistantMessage.content; pending.classList.remove('typing');
      await loadChats();
    } catch (err) { pending.querySelector('.message-content').textContent = `Не получилось отправить сообщение: ${err.message}`; pending.classList.remove('typing'); }
    finally { setBusy(false); input.focus(); }
  }
  composer.addEventListener('submit', e => { e.preventDefault(); sendMessage(); });
  input.addEventListener('input', () => { input.style.height = 'auto'; input.style.height = `${Math.min(input.scrollHeight, 180)}px`; });
  input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); composer.requestSubmit(); } });
  $('#newChat').addEventListener('click', async () => { if (!currentUser) return openAuth('login'); try { await startChat(); closeSidebar(); } catch (err) { toast(err.message); } });
  $('#accountButton').addEventListener('click', () => currentUser ? (confirm(`Выйти из аккаунта ${currentUser.email}?`) && logout()) : openAuth('login'));
  async function logout() { try { await api('/api/logout', { method: 'POST' }); currentUser = null; currentChatId = null; chats = []; conversation.replaceChildren(); showWelcome(); renderAccount(); renderChats(); toast('Ты вышел из аккаунта.'); } catch (err) { toast(err.message); } }
  authForm.addEventListener('submit', async e => {
    e.preventDefault(); authError.textContent = ''; const email = $('#email').value.trim(); const password = $('#password').value; const submit = $('#authSubmit'); submit.disabled = true; submit.textContent = 'Подожди…';
    try {
      const data = await api(`/api/${authMode === 'login' ? 'login' : 'register'}`, { method: 'POST', body: JSON.stringify({ email, password }) });
      currentUser = data.user; currentChatId = null; chats = []; conversation.replaceChildren(); showWelcome(); closeAuth(); renderAccount(); await loadChats(); toast(authMode === 'login' ? 'С возвращением!' : 'Аккаунт создан. Добро пожаловать в HI!');
    } catch (err) { authError.textContent = err.message; }
    finally { submit.disabled = false; setAuthMode(authMode); }
  });
  document.querySelectorAll('.auth-tab').forEach(tab => tab.addEventListener('click', () => { setAuthMode(tab.dataset.mode); authError.textContent = ''; }));
  $('#closeAuth').addEventListener('click', closeAuth);
  authModal.addEventListener('click', e => { if (e.target === authModal) closeAuth(); });
  document.querySelectorAll('.suggestion').forEach(button => button.addEventListener('click', () => sendMessage(button.dataset.prompt)));
  function closeSidebar() { $('#sidebar').classList.remove('open'); }
  $('#openSidebar').addEventListener('click', () => $('#sidebar').classList.add('open'));
  $('#closeSidebar').addEventListener('click', closeSidebar);
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (currentUser) startChat().catch(err => toast(err.message)); else openAuth('login'); } if (e.key === 'Escape') { closeAuth(); closeSidebar(); } });
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  refreshMe();
})();
