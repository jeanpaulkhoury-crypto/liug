require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  if (isProduction) throw new Error('Set SESSION_SECRET to a random value of at least 32 characters.');
  process.env.SESSION_SECRET = 'local-development-only-secret-change-before-deploy-123456';
  console.warn('Using a development-only session secret. Change it before deployment.');
}

const dbFile = path.resolve(process.env.DATABASE_FILE || './data/hi.sqlite');
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL DEFAULT 'New chat',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_chats_user_updated ON chats(user_id, updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id, id);
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '40kb' }));
// The default MemoryStore is for local development only. Configure a persistent
// session store (SQLite/Redis) before deploying publicly.
app.use(session({
  name: isProduction ? '__Host-hi.sid' : 'hi.sid',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many attempts. Please wait and try again.' } });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'You are sending messages too quickly. Please wait a moment.' } });
const requireAuth = (req, res, next) => {
  const userId = req.session.userId;
  if (!userId) return res.status(401).json({ error: 'Please sign in to continue.' });
  const user = db.prepare('SELECT id, email, created_at FROM users WHERE id = ?').get(userId);
  if (!user) { delete req.session.userId; return res.status(401).json({ error: 'Please sign in again.' }); }
  req.user = user;
  next();
};
const validEmail = value => typeof value === 'string' && value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
const publicUser = user => ({ id: user.id, email: user.email, createdAt: user.created_at });

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'HI', aiConfigured: Boolean(process.env.OPENAI_API_KEY) }));
app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = db.prepare('SELECT id, email, created_at FROM users WHERE id = ?').get(req.session.userId);
  res.json({ user: user ? publicUser(user) : null });
});
app.post('/api/register', authLimiter, async (req, res) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = req.body.password;
  if (!validEmail(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (typeof password !== 'string' || password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Password must contain 10–128 characters.' });
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) return res.status(400).json({ error: 'Use at least one letter and one number in your password.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)').run(email, hash);
    const userId = Number(result.lastInsertRowid);
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.userId = userId;
    return res.status(201).json({ user: publicUser(db.prepare('SELECT id, email, created_at FROM users WHERE id = ?').get(userId)) });
  } catch (error) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ error: 'An account with this email already exists.' });
    console.error('Registration failed:', error.message);
    return res.status(500).json({ error: 'Could not create account. Please try again.' });
  }
});
app.post('/api/login', authLimiter, async (req, res) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!validEmail(email) || !password || password.length > 128) return res.status(400).json({ error: 'Enter your email and password.' });
  const user = db.prepare('SELECT id, email, password_hash, created_at FROM users WHERE email = ?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
  await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
  req.session.userId = user.id;
  res.json({ user: publicUser(user) });
});
app.post('/api/logout', (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie(isProduction ? '__Host-hi.sid' : 'hi.sid', { path: '/' });
    res.json({ ok: true });
  });
});

app.get('/api/chats', requireAuth, (req, res) => {
  res.json({ chats: db.prepare('SELECT id, title, created_at AS createdAt, updated_at AS updatedAt FROM chats WHERE user_id = ? ORDER BY updated_at DESC').all(req.user.id) });
});
app.post('/api/chats', requireAuth, (req, res) => {
  const id = crypto.randomUUID();
  const title = typeof req.body.title === 'string' ? req.body.title.trim().slice(0, 80) : '';
  db.prepare('INSERT INTO chats (id, user_id, title) VALUES (?, ?, ?)').run(id, req.user.id, title || 'New chat');
  res.status(201).json({ chat: db.prepare('SELECT id, title, created_at AS createdAt, updated_at AS updatedAt FROM chats WHERE id = ?').get(id) });
});
app.get('/api/chats/:id/messages', requireAuth, (req, res) => {
  const chat = db.prepare('SELECT id FROM chats WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!chat) return res.status(404).json({ error: 'Chat not found.' });
  res.json({ messages: db.prepare('SELECT id, role, content, created_at AS createdAt FROM messages WHERE chat_id = ? ORDER BY id').all(chat.id) });
});
app.delete('/api/chats/:id', requireAuth, (req, res) => {
  const result = db.prepare('DELETE FROM chats WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  if (!result.changes) return res.status(404).json({ error: 'Chat not found.' });
  res.json({ ok: true });
});
app.post('/api/chats/:id/messages', requireAuth, aiLimiter, async (req, res) => {
  const chat = db.prepare('SELECT id, title FROM chats WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!chat) return res.status(404).json({ error: 'Chat not found.' });
  const message = typeof req.body.message === 'string' ? req.body.message.trim() : '';
  if (!message) return res.status(400).json({ error: 'Write a message first.' });
  if (message.length > 8000) return res.status(400).json({ error: 'Messages must be 8,000 characters or fewer.' });
  const insertMessage = db.prepare('INSERT INTO messages (chat_id, role, content) VALUES (?, ?, ?)');
  const saveUser = db.transaction(() => {
    insertMessage.run(chat.id, 'user', message);
    if (chat.title === 'New chat') db.prepare('UPDATE chats SET title = ?, updated_at = datetime(\'now\') WHERE id = ?').run(message.slice(0, 42), chat.id);
    else db.prepare('UPDATE chats SET updated_at = datetime(\'now\') WHERE id = ?').run(chat.id);
  });
  saveUser();

  let answer;
  if (!process.env.OPENAI_API_KEY) {
    answer = 'Привет! Я HI — твой ИИ-ассистент. Сейчас я работаю в режиме настройки: добавь OPENAI_API_KEY в файл .env и перезапусти сервер, чтобы включить настоящие ответы ИИ. Твоё сообщение уже сохранено в истории.';
  } else {
    try {
      const history = db.prepare('SELECT role, content FROM messages WHERE chat_id = ? ORDER BY id DESC LIMIT 20').all(chat.id).reverse();
      const response = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', instructions: 'You are HI, a helpful AI assistant. Respond in the language used by the user. Be clear and honest.', input: history.map(item => ({ role: item.role, content: item.content })) })
      });
      const data = await response.json();
      if (!response.ok) {
        console.error('AI provider error:', response.status, data.error?.message || 'Unknown error');
        return res.status(502).json({ error: 'The AI service could not answer right now. Check your API key, model access, and account billing.' });
      }
      answer = data.output_text || (data.output || []).flatMap(item => item.content || []).filter(item => item.type === 'output_text').map(item => item.text).join('\n');
      if (!answer) throw new Error('AI provider returned an empty response');
    } catch (error) {
      console.error('AI request failed:', error.message);
      return res.status(502).json({ error: 'Could not reach the AI service. Check your connection and try again.' });
    }
  }
  insertMessage.run(chat.id, 'assistant', answer);
  db.prepare('UPDATE chats SET updated_at = datetime(\'now\') WHERE id = ?').run(chat.id);
  res.status(201).json({ userMessage: { role: 'user', content: message }, assistantMessage: { role: 'assistant', content: answer } });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});
const server = app.listen(PORT, () => console.log(`HI is running at http://localhost:${PORT}`));
function shutdown() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
