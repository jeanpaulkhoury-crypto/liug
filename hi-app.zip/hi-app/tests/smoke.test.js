const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
test('project contains server, responsive client, and PWA assets', () => {
  for (const file of ['server.js', 'package.json', 'public/index.html', 'public/styles.css', 'public/app.js', 'public/manifest.webmanifest', 'public/sw.js']) {
    assert.ok(fs.existsSync(path.join(root, file)), `Missing ${file}`);
  }
});
test('server uses hashed passwords and owner-scoped chat lookups', () => {
  const source = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(source, /bcrypt\.hash\(password, 12\)/);
  assert.match(source, /WHERE id = \? AND user_id = \?/);
  assert.match(source, /OPENAI_API_KEY/);
});
